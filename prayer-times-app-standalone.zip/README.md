# Prayer Times — standalone version (free, no login required)

This is a self-hosted version of the Prayer Times app. No one needs a
Claude account (or any account) to use it, it costs nothing to run, and it
can live at your own URL for as long as you like.

It uses **Google's Gemini API**, which — unlike Anthropic's API — has a
genuinely ongoing free tier: no credit card, no expiration, just a daily
request limit that's generous enough for a community app like this.

Your API key stays on the server (`api/extract.js`), never in the browser,
so it can't be copied by anyone inspecting the page.

## What you'll need

- A free [Google AI Studio](https://aistudio.google.com/apikey) account —
  no credit card required.
- A free [Vercel](https://vercel.com) account (or Netlify — steps are
  similar).
- A free [GitHub](https://github.com) account, to hold the code so Vercel
  can deploy it.

## Step 1 — Get your free Gemini API key

1. Go to [aistudio.google.com/apikey](https://aistudio.google.com/apikey)
   and sign in with any Google account.
2. Click **Create API key**. Copy it — you'll paste it into Vercel in
   Step 3.
3. That's it — no billing setup needed for the free tier.

## Step 2 — Put this code on GitHub

1. Create a new (empty) repository on GitHub, e.g. `prayer-times-app`.
2. From this project folder, run:
   ```
   git init
   git add .
   git commit -m "Prayer times app"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/prayer-times-app.git
   git push -u origin main
   ```

## Step 3 — Deploy to Vercel

1. Go to vercel.com → **Add New → Project** → import the GitHub repo you
   just created.
2. Vercel auto-detects it as a Vite project — leave the build settings as
   default.
3. Before deploying, open **Environment Variables** and add:
   - Name: `GEMINI_API_KEY`
   - Value: the key you copied in Step 1
4. Click **Deploy**. After a minute or two you'll get a live URL like
   `prayer-times-app.vercel.app` — that's the link you share.

## Step 4 — (Optional) Use your own domain

In the Vercel project → **Settings → Domains**, you can attach a domain
you own (e.g. `prayertimes.yourmosque.org`) instead of the vercel.app one.

## About the free tier limits

The app uses the `gemini-2.5-flash` model by default, which allows roughly
250 requests per day for free — plenty for a mosque community uploading a
monthly timetable a handful of times. If you expect much heavier traffic
(many different mosques all using the same deployment, for example), open
`api/extract.js` and change `GEMINI_MODEL` to `'gemini-2.5-flash-lite'`,
which allows around 1,000 requests/day for free, in exchange for slightly
less careful reading of messy tables.

If you ever did exceed the free daily cap, requests would simply fail
until the quota resets the next day — no charge is possible unless you
separately enable billing on the Google Cloud project, which this setup
does not require.

## Updating it later

Any time you want to change something, edit the code and:
```
git add .
git commit -m "describe your change"
git push
```
Vercel redeploys automatically within a minute or two of every push.

## Alternative: deploy without GitHub (Vercel CLI)

If you'd rather skip GitHub entirely:
```
npm install -g vercel
cd this-project-folder
vercel
```
Follow the prompts, then set the environment variable with:
```
vercel env add GEMINI_API_KEY
```
and redeploy with `vercel --prod`.

## Local testing (optional)

```
npm install
cp .env.example .env.local   # then paste your real key in
```
Note: the local dev server won't run the `/api/extract` function unless you
use `vercel dev` instead of `npm run dev` — that command runs both the
frontend and the serverless function together, matching production.
